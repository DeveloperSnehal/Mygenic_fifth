<?php
    $con = mysqli_connect('localhost','root','','mygenic_db');

    if(!$con){
        echo "connection is successfull!";
    }
?>